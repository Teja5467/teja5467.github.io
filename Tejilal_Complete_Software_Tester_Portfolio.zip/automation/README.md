# OrangeHRM Selenium Automation — Tejilal

## Automation stack
- Java
- Selenium WebDriver
- JUnit 5
- Maven
- Chrome

## Automated smoke flow
1. Launch OrangeHRM
2. Locate username field
3. Locate password field
4. Submit login
5. Wait for the Dashboard URL
6. Verify dashboard navigation
7. Click **PIM**
8. Wait for the PIM page
9. Verify PIM navigation
10. Quit the browser

## Selenium concepts demonstrated
- `WebDriver`
- `ChromeDriver`
- `WebDriverWait`
- `ExpectedConditions`
- XPath
- CSS selectors
- `findElement()`
- `sendKeys()`
- `click()`
- `getCurrentUrl()`
- Assertions
- `@BeforeEach` / `@AfterEach`
- Page synchronization using explicit waits

## Running locally

Set the following environment variables if you are using a different OrangeHRM instance:

```text
ORANGEHRM_BASE_URL
ORANGEHRM_USERNAME
ORANGEHRM_PASSWORD
```

Then run:

```bash
mvn test
```

Never commit real credentials to GitHub.

TEJA — CINEMATIC QA PORTFOLIO

HOW TO PREVIEW
1. Extract this ZIP file.
2. Open index.html in Chrome, Edge, Firefox, or another modern browser.
3. Internet is needed for Google Fonts. The rest of the site works as a standalone page.

FEATURES
- Responsive dark cinematic design
- Animated section reveals and mobile navigation
- Cursor-following light on desktop
- Subtle 3D tilt on skill and project cards
- Download Resume button linked to Teja_Resume_Template.txt

BEFORE PUBLISHING
- Edit Teja_Resume_Template.txt and replace contact placeholders.
- The resume file is a text starter template, not a finished professional PDF.
- Replace sample project cards with real completed projects.
- Verify that you can explain all listed skills in an interview.
- Add your real email, LinkedIn, and GitHub links to index.html.

PUBLISHING
Upload the contents of this folder to GitHub Pages or Netlify for a public website link.
